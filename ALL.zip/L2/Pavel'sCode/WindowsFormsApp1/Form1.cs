﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1 {
    public partial class Form1 : Form {
        class Closure {
            public int z;
            public void f(object sender, EventArgs e) {
                MessageBox.Show(z.ToString());
            }
        }

        public Form1() {
            InitializeComponent();

            var c = new Closure();
            c.z = 9;
            button1.Click += c.f;
            c.z++;

            int z = 9;
            EventHandler h = (s, e) => {
                MessageBox.Show(z.ToString());
            };
            button1.Click += h;

            button1.Click -= h;


            z++;
        }

    }
}
