﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace ConsoleApp11
{
    public class LINQtoObjects
    {
        static void Main(string[] args)
        {
            Console.WriteLine(printInterfacesSortedByName());
            Console.ReadKey();
        }

        private static string printInterfacesSortedByName()
        {
            string str = "";
            var interfaces = from i in typeof(object).Assembly /* To get to: mscorlib */.GetTypes()
                where i.IsInterface && i.IsPublic
                orderby i.Name
                select new
                {
                    Name = i.FullName,
                    NumOfMethods = i.GetMethods().Length
                };

            foreach (var inter in interfaces)
            {
                str += " " + inter;
            }

            return str;
        }
    }
}