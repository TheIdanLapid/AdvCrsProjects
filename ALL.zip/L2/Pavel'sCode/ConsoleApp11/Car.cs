﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11 {
    class CarTooFastEventArgs : EventArgs {
        public readonly int Speed;

        internal CarTooFastEventArgs(int speed) {
            Speed = speed;
        }
    }

    class Car {
        public int Speed { get; private set; }
        public void Accelerate(int amount) {
            int oldSpeed = Speed;
            Speed += amount;
            if (Speed > 100 && oldSpeed <= 100) {
                OnCarTooFast(new CarTooFastEventArgs(Speed));
            }
        }

        protected virtual void OnCarTooFast(CarTooFastEventArgs e) {
            if (_carTooFast != null)
                _carTooFast(this, e);
        }

        private EventHandler<CarTooFastEventArgs> _carTooFast;
        public event EventHandler<CarTooFastEventArgs> CarTooFast {
            add {
                _carTooFast += value;
            }
            remove {
                _carTooFast -= value;
            }
        }        

    }
}
