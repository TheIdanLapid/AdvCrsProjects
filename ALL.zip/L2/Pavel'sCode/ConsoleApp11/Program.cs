﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11 {
    #region WeakReference
    interface INotify {
        void Notify(int value);
    }

    class Producer {
        GCHandle _handle;
        public void DoWork() {
            var c = (INotify)_handle.Target;
            if (c != null)
                c.Notify(100);
            else
                _handle.Free();
        }

        public void Register(INotify notify) {
            _handle = GCHandle.Alloc(notify, GCHandleType.Weak);
        }
    }

    class Consumer : INotify {
        public void Notify(int value) {
            Console.WriteLine(value);
        }
    }
    #endregion

    static class StringExtensions {
        public static string ReverseString(string s) {
            var chars = s.ToCharArray();
            Array.Reverse(chars);
            return new string(chars);
        }

        public static string Reverse(this string s) {
            var chars = s.ToCharArray();
            Array.Reverse(chars);
            return new string(chars);
        }

        public static string DupString(string s, char ch) {
            return s + ch + s;
        }

        public static string Dup(this string s, char ch) {
            return s + ch + s;
        }

        public static bool IsNullOrEmpty(this string s) {
            return string.IsNullOrEmpty(s);
        }

        public static string GetTypeName(this object o) {
            return o.GetType().FullName;
        }

        public static TimeSpan Seconds(this int n) {
            return TimeSpan.FromSeconds(n);
        }

        //public static IEnumerable<T> Where<T>(this IEnumerable<T> source,
        //    Func<T, bool> predicate) {
        //    foreach (var item in source)
        //        if (predicate(item))
        //            yield return item;
        //}
    }

    class Program {
        static bool Even(int n) {
            return n % 2 == 0;
        }

        static void MainCHANGETHISBACKTOMain(string[] args) {
            string s = "hello";
            Console.WriteLine(StringExtensions.ReverseString(s));
            Console.WriteLine(StringExtensions.DupString(s, '*'));
            Console.WriteLine(StringExtensions.ReverseString(StringExtensions.DupString(s, '*')));
            Console.WriteLine(s.Reverse());
            Console.WriteLine(s.Dup('*'));
            Console.WriteLine(s.Reverse().Dup('*'));
            Console.WriteLine(string.IsNullOrEmpty(s));
            Console.WriteLine(s.IsNullOrEmpty());
            Console.WriteLine(s.GetTypeName());
            Console.WriteLine(5.GetTypeName());
            var ts = 4.Seconds();

            
            //return;

            var p1 = new {
                Name = "Bart",
                Age = 10
            };
            var p2 = new {
                Name = "Homer",
                Age = 40
            };

            Console.WriteLine(p1.GetType().Name);
            Console.WriteLine(p1);
            var d = new Dictionary<int, string> {
                { 3, "three" },
                { 10, "ten" },
            };
            var list = new List<int> {
                1, 44, 56, 77, 22, 37, 50, 45, 30, 88, 121, 100, 6, 11
            };
            /*            List<int> list2 = list.FindAll(Even);
                        List<int> list3 = list.FindAll(delegate(int n) {
                            return n % 2 == 0;
                        });
                        List<int> list4 = list.FindAll((n) => n % 2 == 0);
            */
            var list2 = list.Where(n => n % 2 == 0).OrderBy(n => n.ToString())
                .Select(n => n);
            list.Add(200);
            foreach (int n in list2)
                Console.WriteLine(n);

            int sum = list.Sum();
            Console.WriteLine(sum);

            var list3 = from n in list
                        where n % 2 == 0
                        orderby n.ToString()
                        select new {
                            Original = n,
                            Squared = n * n
                        };

            foreach (var n in list3)
                Console.WriteLine(n);

            var q1 = from p in Process.GetProcesses()
                     where p.Threads.Count > 10
                     orderby p.ProcessName descending, p.Id
                     select new {
                         Name = p.ProcessName,
                         Id = p.Id,
                         Threads = p.Threads.Count,
                         Priority = p.BasePriority
                     };

            Console.WriteLine(Process.GetProcesses().
                Sum(p => p.Threads.Count));
            var result = Process.GetProcesses().
                Aggregate("All processes: ",
                (all, p) => all + p.ProcessName + " ");
            Console.WriteLine(result);

            var q2 = Process.GetProcesses().
                Where(p => p.Threads.Count > 10).
                OrderByDescending(p => p.ProcessName).
                ThenBy(p => p.Id).
                Select(p => new {
                    Name = p.ProcessName,
                    Id = p.Id,
                    Threads = p.Threads.Count,
                    Priority = p.BasePriority
                }).ToDictionary(p => p.Id);

            //var s2 = new string(s.Reverse().ToArray());
            foreach (var p in q2)
                Console.WriteLine(p);

            var q3 = from p in Process.GetProcesses()
                     from t in p.Threads.OfType<ProcessThread>()
                     select new {
                         Name = p.ProcessName,
                         Tid = t.Id
                     };


            var car = new Car();
            car.CarTooFast += (sender, e) => {
                Console.WriteLine("Too fast!!! {0}", e.Speed);
            };
            car.CarTooFast += Car_CarTooFast;
            //car.CarTooFast(300);

            /*            var rnd = new Random();
                        for (int i = 0; i < 20; i++) {
                            car.Accelerate(rnd.Next(10) + 5);
                            Console.WriteLine("Speed: {0}", car.Speed);
                        }
            */
            //foreach (int n in CalcPrimes(3, 1000000000)) {
            //    if (n > 500)
            //        break;
            //    Console.WriteLine(n);
            //}

        }

        static IEnumerable<int> CalcPrimes(int first, int last) {
            var name = default(string);

            for (int i = first; i <= last; i++) {
                int limit = (int)Math.Sqrt(i);
                bool isPrime = true;
                for (int j = 2; j <= limit; j++)
                    if (i % j == 0) {
                        isPrime = false;
                        break;
                    }
                if (isPrime)
                    yield return i;
            }
        }

        private static void Car_CarTooFast(object sender, EventArgs e) {
            Console.WriteLine();
        }
    }
}
