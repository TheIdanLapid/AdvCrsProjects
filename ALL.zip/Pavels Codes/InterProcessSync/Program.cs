﻿#define SYNC

using System;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace InterProcessSync {
	static class Program {
		static void Main(string[] args) {
			using(var mutex = new Mutex(false, "MyMutex")) {
				Console.WriteLine("Process ID: {0}", Process.GetCurrentProcess().Id);
				Console.WriteLine("Press Enter to start... Mutex handle=0x{0:X}", mutex.SafeWaitHandle.DangerousGetHandle().ToInt64());
				Console.ReadLine();

				Console.WriteLine("Writing...");

				for(int i = 0; i < 500; i++) {
#if SYNC
					mutex.WaitOne();
#endif
					try {
						using(var writer = new StreamWriter(@"c:\temp\test.txt", true)) {
							writer.WriteLine("Writing information from process " + 
								Process.GetCurrentProcess().Id);
						}
					}
					catch(Exception e) {
						Console.WriteLine("Exception: {0}", e.Message);
						return;
					}
					finally {
#if SYNC
						mutex.ReleaseMutex();
#endif
					}
				}

				Console.WriteLine("Done.");
			}
		}
	}
}
