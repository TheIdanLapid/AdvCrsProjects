﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ProjectBuilder {
	static class Program {
		static void Main(string[] args) {
			Console.WriteLine("Serial");
			var sw = Stopwatch.StartNew();
			BuildSerial();
			sw.Stop();
			Console.WriteLine("Sequential build: {0}", sw.ElapsedMilliseconds);

			Console.WriteLine();
			Console.WriteLine("Parallel");
			sw.Restart();
			BuildParallel();
			sw.Stop();
			Console.WriteLine("Parallel build: {0}", sw.ElapsedMilliseconds);
		}

		static void BuildProject(int index) {
			Console.WriteLine("Building project {0}...", index);
			Thread.Sleep(1000);
			Console.WriteLine("\tDone building {0}.", index);
		}

		static void BuildParallel() {
			var t1 = Task.Run(() => BuildProject(1));
			var t2 = Task.Run(() => BuildProject(2));
			var t3 = Task.Run(() => BuildProject(3));
			var t4 = t1.ContinueWith(_ => BuildProject(4));
			var t5 = Task.Factory.ContinueWhenAll(new Task[] { t1, t2, t3 }, _ => BuildProject(5));
			var t6 = Task.Factory.ContinueWhenAll(new Task[] { t3, t4 }, _ => BuildProject(6));
			var t7 = Task.Factory.ContinueWhenAll(new Task[] { t5, t6 }, _ => BuildProject(7));
			var t8 = t5.ContinueWith(_ => BuildProject(8));

			Task.WaitAll(t7, t8);
		}

		static void BuildSerial() {
			BuildProject(1);
			BuildProject(2);
			BuildProject(3);
			BuildProject(4);
			BuildProject(5);
			BuildProject(6);
			BuildProject(7);
			BuildProject(8);
		}
	}
}
