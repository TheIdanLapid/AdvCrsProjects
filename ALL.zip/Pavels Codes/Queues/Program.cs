﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Queues {
	class Program {
		static void Main(string[] args) {

			var queue = new LimitedQueue<int>(25);
			var th = new Thread(() => {
				for(; ; ) {
					Console.WriteLine("Items in Queue: {0}", queue.Count);
					Thread.Sleep(80);
				}
			});
			th.IsBackground = false;
			th.Start();

			for(int i = 0; i < 50; i++) {
				ThreadPool.QueueUserWorkItem((o) => {
					var rnd = new Random(Thread.CurrentThread.ManagedThreadId);
					for(int j = 0; j < 100; j++) {
						if(rnd.Next(10) >= 5)
							queue.Enque(rnd.Next(100));
						else {
							try {
								queue.Deque();
							}
							catch {
							}
						}
						Thread.Sleep(rnd.Next(20));
					}
				});
			}
			Thread.Sleep(10000);
		}
	}
}
