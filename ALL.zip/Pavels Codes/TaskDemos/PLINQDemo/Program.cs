﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace PLINQDemo {
	class Program {
		static void Main(string[] args) {
			ObsoleteMembers(typeof(string).Assembly);
		}

		static void ObsoleteMembers(Assembly asm) {
			var query = from type in asm.GetExportedTypes().AsParallel()
							from member in type.GetMembers(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance)
							where Attribute.IsDefined(member, typeof(ObsoleteAttribute))
							orderby type.FullName, member.Name
							select new {
								Name = type.FullName + "." + member.Name,
								Type = member.MemberType
							};
			foreach(var result in query)
				Console.WriteLine(result);
		}
	}
}
