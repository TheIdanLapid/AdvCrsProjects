﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ParallelTree {
	static class Program {
		static void Main(string[] args) {
			var rnd = new Random();
			var tree = Tree<int>.Build(11, () => rnd.Next(100));
			//Console.ReadLine();
			var sw = Stopwatch.StartNew();

			// walk the tree
			WalkTreeTasks(tree, i => Thread.Sleep(10));

			sw.Stop();
			Console.WriteLine("Elapsed: {0}", sw.ElapsedMilliseconds);
		}

		static void WalkTreeSequential(Tree<int> tree, Action<int> action = null) {
			if (tree == null) return;

			WalkTreeSequential(tree.Left, action);
			WalkTreeSequential(tree.Right, action);

			action(tree.Data);
		}

		static void WalkTreeThreadPool(Tree<int> tree, Action<int> action = null) {
			if (tree == null) return;

			var ev = new AutoResetEvent(false);
			int count = 2;

			ThreadPool.QueueUserWorkItem(_ => {
				WalkTreeThreadPool(tree.Left, action);
				if (Interlocked.Decrement(ref count) == 0)
					ev.Set();
			});
			ThreadPool.QueueUserWorkItem(_ => {
				WalkTreeThreadPool(tree.Right, action);
				if (Interlocked.Decrement(ref count) == 0)
					ev.Set();
			});

			ev.WaitOne();

			action(tree.Data);
		}

		static void WalkTreeTasks(Tree<int> tree, Action<int> action = null) {
			if (tree == null) return;

			var t1 = Task.Run(() => WalkTreeTasks(tree.Left, action));
			var t2 = Task.Run(() => WalkTreeTasks(tree.Right, action));

			try {
				Task.WaitAll(t1, t2);
			}
			catch (AggregateException ex) {
				
				if (ex.GetBaseException() is TaskCanceledException) {
				}
			}

			action(tree.Data);
		}
	}
}
