﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParallelTree {
	class Tree<T> {
		public Tree<T> Left { get; private set; }
		public Tree<T> Right { get; private set; }
		public T Data { get; set; }

		public int Count { get; private set; }

		public static Tree<T> Build(int depth, Func<T> nextValue) {
			int count = 1;
			var root = new Tree<T> { Data = nextValue() };
			BuildHelper(root, depth - 1, nextValue, ref count);
			root.Count = count;
			return root;
		}

		private static void BuildHelper(Tree<T> root, int currentDepth, Func<T> nextValue, ref int count) {
			if(currentDepth < 1) return;

			root.Left = new Tree<T> { Data = nextValue() };
			count++;
			BuildHelper(root.Left, currentDepth - 1, nextValue, ref count);
			root.Right = new Tree<T> { Data = nextValue() };
			count++;
			BuildHelper(root.Right, currentDepth - 1, nextValue, ref count);
		}
	}
}
