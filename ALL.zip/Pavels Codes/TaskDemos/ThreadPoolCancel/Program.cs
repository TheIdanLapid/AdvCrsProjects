﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadPoolCancel {
	class CancellationDemo {
		public static void RunDemo() {
			var cts = new CancellationTokenSource();
			ThreadPool.QueueUserWorkItem(_ => DoWork(cts.Token, 1000));
			Console.WriteLine("Press ENTER to cancel operation");
			Console.ReadLine();
			cts.Cancel();
			Thread.Sleep(400);
		}

		private static void DoWork(CancellationToken ct, int data) {
			for(int i = 0; i < data; i++) {
				if(ct.IsCancellationRequested) {
					Console.WriteLine("cancelled...");
					break;
				}
				// do some work...
				Console.WriteLine(i);
				Thread.Sleep(50);	// waste some time
			}
		}
	}
	class Program {
		static void Main(string[] args) {
			CancellationDemo.RunDemo();
		}
	}
}
