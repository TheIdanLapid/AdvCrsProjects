﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParallelTree {
	class Tree<T> {
		public Tree<T> Left { get; private set; }
		public Tree<T> Right { get; private set; }
		public T Data { get; set; }

		public static Tree<T> Build(int depth, Func<T> nextValue) {
			var root = new Tree<T> { Data = nextValue() };
			BuildHelper(root, depth, nextValue);
			return root;
		}

		private static void BuildHelper(Tree<T> root, int currentDepth, Func<T> nextValue) {
			if(currentDepth <= 0) return;

			root.Left = new Tree<T> { Data = nextValue() };
			BuildHelper(root.Left, currentDepth - 1, nextValue);
			root.Right = new Tree<T> { Data = nextValue() };
			BuildHelper(root.Right, currentDepth - 1, nextValue);
		}
	}
}
